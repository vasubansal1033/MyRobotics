function [nodes, parents, solution] = dynamic_rrt(map, goalIdx, parameters, startIdx)
% Function to perform RRT taking into account robot dynamics.
% This does not need to be filled in and will be shown in the solutions as
% a rough example for one of many possible extensions for the algorithm.
end
